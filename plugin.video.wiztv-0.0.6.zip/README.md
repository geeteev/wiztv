# wiztv
Based entirely on Sanctuary, all credit to the developers of that and all the addons inside it. Intention is to remove most of the Sanctuary content and develop this into a mainly IPTV list and search addon
